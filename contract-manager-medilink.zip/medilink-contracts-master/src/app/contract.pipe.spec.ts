import { ContractPipe } from './contract.pipe';

describe('ContractPipe', () => {
  it('create an instance', () => {
    const pipe = new ContractPipe();
    expect(pipe).toBeTruthy();
  });
});
